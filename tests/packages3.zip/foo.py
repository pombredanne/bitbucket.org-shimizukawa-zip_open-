import os
from zip_open import zopen

def loader(filename):
    fobj = zopen(os.path.join(os.path.dirname(__file__), filename))
    return fobj

